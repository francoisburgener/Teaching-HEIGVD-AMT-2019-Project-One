USE `amt-db` ;
INSERT INTO User (username,fullname,email,password)VALUES('jean','jean','jean@jean.jea','$2a$10$r4oQCV4Ip3BRM2CGcYnxcuVryKqeTlDXibP6xG/kIiAeNiTXNVkbO');
INSERT INTO User (username,fullname,email,password)VALUES('philipe','philipe','philipe@philipe.phi','$2a$10$wRX.YWF2uqjxDAVRQNA8Kepa6EWn1JLUcWI3r1IJ3GmCUsIUso.iu');
INSERT INTO User (username,fullname,email,password)VALUES('moutarde','moutarde','moutarde@moutarde.com','$2a$10$Jc0D1U5xRESNP1FD1jJ5feGPioY7rtiOC17AiuurlRIO070KmAatK');
INSERT INTO User (username,fullname,email,password)VALUES('ail','ail','ail@ail.com','$2a$10$83TQV.BaxIdXl8E4pImYzOxBvSMzkSzvZ10AVQ79B1rM3k5ULiVKm');
INSERT INTO User (username,fullname,email,password)VALUES('blip','blip','blip@blip.com','$2a$10$ApMNXETgI.uQkatgk38dsuqDxuuNTOZ0rOpjVDJjdeRgmJxquMbua');
INSERT INTO User (username,fullname,email,password)VALUES('password','password','password@password.com','$2a$10$c1yIH6qneHLWx69RPemFHubFG5KAVASies3U0d/QzN0j5hJGhnPFG');
INSERT INTO User (username,fullname,email,password)VALUES('123456','123456','123456@123456.com','$2a$10$ZalYaMrKaZwe6/dIKew6b.pcqnOemh01iJ68xLReN7vXlxlt.JHYK');
INSERT INTO User (username,fullname,email,password)VALUES('albert','einstein','albert@albert.com','$2a$10$vdIgG2NWNT3Mkez1L4xHuOWcx6wt4armyFDmNzZzbOTf5wJCLEeRi');
INSERT INTO User (username,fullname,email,password)VALUES('spam','spam','spam@spam.com','$2a$10$lz5L2ptpp0vh2imdpQTqfuX.r1HI3qUv2847BoqIhI6s8xrktjtw6');
INSERT INTO User (username,fullname,email,password)VALUES('michel','michel','michel@michel.com','$2a$10$KqJqb3jkG3hMvfEj7dSo4u1PaLSANU6MG5w8yxsKdLjn8/bhj73ae');

    